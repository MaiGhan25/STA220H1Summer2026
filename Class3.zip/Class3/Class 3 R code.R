# STA220 Class 3 R Code

#Reading in a data file

# Make sure the data file is saved in your "Working Directory". 
# That is the folder in which R is working in.
# Check your current working directory using getwd()
getwd()

# Change your working directory either by clicking on "Session" then "Set Working Directory", 
# or running the setwd() function
setwd("~/Teaching/Class3 R code") #Change this line to be where your files are saved

# Data files are usually saved as .txt or .csv files.
# Use read.csv to read in the files
pizza_data <- read.csv("Pizza.csv")

# There are optional arguments you can put into the function
pizza_data <- read.csv("Pizza.csv", header = TRUE, sep = ",") 
#The "header = TRUE" arguement means that the first row of our CSV file has variable names, and we should not treat it as data


# head() allows us to take a peak at the first few rows of the data
head(pizza_data)

# tail() allows us to take a peak at the last few rows of the data
tail(pizza_data)

# dim() gives the dimensions of the data
dim(pizza_data)


#Most people use the $ to access variables
pizza_data$Sales #this prints the Sales column of the pizza data
pizza_data$Price #prints the price column

#Now, we can do some stuff with the data

#Plot a scatterplot of two variables
plot(pizza_data$Price, pizza_data$Sales, xlab = "Price in dollars", ylab = "Sales", main = "Pizza Sales vs Price")

#Histogram of pizza sales
hist(pizza_data$Sales, xlab = "Sales", main = "Histogram for Pizza Sales")


#Measures of Center and Spread
mean(pizza_data$Sales)
mean(pizza_data$Sales, trim=0.10) #This is the 10% trimmed mean
median(pizza_data$Sales)
range(pizza_data$Sales) 
sd(pizza_data$Sales)
var(pizza_data$Sales)
IQR(pizza_data$Sales)

#Can also sort the data easily 
sort(pizza_data$Price)

#Or find quantiles
quantile(pizza_data$Price, 0.25)

#Or check how which entries have price less than $3.50, we get some trues and falses
pizza_data$Price < 3.5
#Can use this to filter the data
pizza_data$Price[pizza_data$Price < 3.5] #only keep the entries that are less than 3.5
